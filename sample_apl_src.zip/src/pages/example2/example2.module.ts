import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Example2Page } from './example2';

@NgModule({
  declarations: [
    Example2Page,
  ],
  imports: [
    IonicPageModule.forChild(Example2Page),
  ],
})
export class Example2PageModule {}
