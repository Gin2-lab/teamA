import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Example6Page } from './example6';

@NgModule({
  declarations: [
    Example6Page,
  ],
  imports: [
    IonicPageModule.forChild(Example6Page),
  ],
})
export class Example6PageModule {}
