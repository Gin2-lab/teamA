import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Example5Page } from './example5';

@NgModule({
  declarations: [
    Example5Page,
  ],
  imports: [
    IonicPageModule.forChild(Example5Page),
  ],
})
export class Example5PageModule {}
