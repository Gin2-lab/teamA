import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';

import { AboutPage } from '../pages/about/about';
import { ContactPage } from '../pages/contact/contact';
import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

//各サンプルのページ
import { Example1Page } from '../pages/example1/example1';
import { Example2Page } from '../pages/example2/example2';
import { Example3Page } from '../pages/example3/example3';
import { Example4Page } from '../pages/example4/example4';
import { Example5Page } from '../pages/example5/example5';
import { Example6Page } from '../pages/example6/example6';

//サンプルページの子ページ
import { ScanPageModule } from '../pages/scan/scan.module';
import { CameraPageModule } from '../pages/camera/camera.module';
import { SpeechRecognitionPageModule} from '../pages/speech-recognition/speech-recognition.module'
import { GeolocationPageModule } from '../pages/geolocation/geolocation.module';

//追加部品
import { GitHubUsersServiceProvider } from '../providers/git-hub-users-service/git-hub-users-service';
import { HttpClientModule } from '@angular/common/http'; 
import { GoogleMaps } from "@ionic-native/google-maps";
import { Geolocation } from '@ionic-native/geolocation';
import { Base64ToGallery } from '@ionic-native/base64-to-gallery';
import { SpeechRecognition } from '@ionic-native/speech-recognition';
import { HTTP } from '@ionic-native/http';


@NgModule({
  declarations: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,

    //各サンプルのページ宣言
    Example1Page,
    Example2Page,
    Example3Page,
    Example4Page,
    Example5Page,
    Example6Page
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    //追加モジュール
    HttpClientModule,
    ScanPageModule,
    CameraPageModule,
    SpeechRecognitionPageModule,
    GeolocationPageModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,

    //各サンプルのページエントリ
    Example1Page,
    Example2Page,
    Example3Page,
    Example4Page,
    Example5Page,
    Example6Page
  ],
  providers: [
    StatusBar,
    SplashScreen,
    
    //追加したプロバイダ
    GitHubUsersServiceProvider,
    GoogleMaps,
    Geolocation, 
    Base64ToGallery,
    SpeechRecognition,
    HTTP,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}