import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
//カメラ機能
import { Camera, CameraOptions } from '@ionic-native/camera';
import { Base64ToGallery } from '@ionic-native/base64-to-gallery';
/**
 * Generated class for the CameraPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-camera',
  templateUrl: 'camera.html',
  providers: [Camera],
})
export class CameraPage {

  imgSrc: string;

  constructor(private camera: Camera, private base64ToGallery: Base64ToGallery) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CameraPage');
  }

  takePicture() {

    console.log('CameraPage takePicture');

    const options: CameraOptions = {
      quality: 75,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE
    };

    this.camera
      .getPicture(options)
      .then((imageData) => {
        let base64Image = 'data:image/jpeg;base64,' + imageData;
        this.imgSrc = base64Image;

        console.log('CameraPage getPicture');        

        // 画像を保存(mediaScannerをtrueにすると保存されるはずだが、アプリが落ちる))
        this.base64ToGallery.base64ToGallery(
          imageData,
          {prefix: 'img_', mediaScanner:false}
        )
          .then((res) => {
            console.log(`OK - ${res}`);
          })
          .catch((err) => {
            console.log(`Error ${err}`);
          });
      })
      .catch((err) => {
        console.log(err);
      });
  }
}
