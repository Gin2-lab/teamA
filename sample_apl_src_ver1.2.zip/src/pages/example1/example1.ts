import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
//Map関連モジュールのimport
import { GeolocationPage } from '../geolocation/geolocation';
import { GoogleMapPage } from '../google-map/google-map';

/**
 * Generated class for the Example1Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-example1',
  templateUrl: 'example1.html',
})

export class Example1Page {

  constructor(public navCtrl: NavController) { }

  ionViewDidLoad() {
    console.log('ionViewDidLoad example1Page');
  }

  goPage(pageName: string) {
    switch (pageName) {
      case 'geolocation':
        this.navCtrl.push(GeolocationPage);
        break;
      case 'googlemap':
        this.navCtrl.push(GoogleMapPage);
        break;
    }
  }
}