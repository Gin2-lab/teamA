import { Component } from '@angular/core';
import { IonicPage, NavController, Platform } from 'ionic-angular';
//音声認識プラグイン
import { SpeechRecognition } from '@ionic-native/speech-recognition';
/**
 * Generated class for the SpeechRecognitionPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-speech-recognition',
  templateUrl: 'speech-recognition.html',
})
export class SpeechRecognitionPage {
  matches: String[];
  isRecording = false;

  constructor(
    public navCtrl: NavController,
    private platform: Platform,
    private speechRecognition: SpeechRecognition
  ) {
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      speechRecognition.stopListening();
      console.log('SpeechRecognition ready');
    });
  }

  isIos() {
    return this.platform.is('ios');
  }

  stopListening() {
    this.speechRecognition.stopListening().then(() => {
      this.isRecording = false;
    });
  }

  getPermission() {
    this.speechRecognition.hasPermission()
      .then((hasPermission: boolean) => {
        if (!hasPermission) {
          this.speechRecognition.requestPermission();
        }
      });
  }

  startListening() {  
    this.speechRecognition.startListening().subscribe(matches => {
      this.matches = matches;
    });
    this.isRecording = true;
  }

}
