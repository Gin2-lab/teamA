import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Example4Page } from './example4';

@NgModule({
  declarations: [
    Example4Page,
  ],
  imports: [
    IonicPageModule.forChild(Example4Page),
  ],
})
export class Example4PageModule {}
