import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Example3Page } from './example3';

@NgModule({
  declarations: [
    Example3Page,
  ],
  imports: [
    IonicPageModule.forChild(Example3Page),
  ],
})
export class Example3PageModule {}
