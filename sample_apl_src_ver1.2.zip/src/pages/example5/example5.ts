import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
//音声認識
import { SpeechRecognitionPage } from '../speech-recognition/speech-recognition';
/**
 * Generated class for the Example5Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-example5',
  templateUrl: 'example5.html',
})
export class Example5Page {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Example5Page');
  }

  goPage(pageName: string){
    switch(pageName){
      case 'speechrecognition':
        this.navCtrl.push(SpeechRecognitionPage);
        break;
    }
  }
}
