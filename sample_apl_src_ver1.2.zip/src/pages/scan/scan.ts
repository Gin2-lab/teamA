import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
//バーコードリーダー
import { BarcodeScanner } from '@ionic-native/barcode-scanner';

/**
 * Generated class for the ScanPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-scan',
  templateUrl: 'scan.html',
  styles: [`
  .scan-result{
    background-color:#eee;
    padding:1em;
    font-size:2em;
  }
  `],
  providers: [ BarcodeScanner ]
})
export class ScanPage {

  scannedText: string;
  format: string;

  constructor(
    public barcodeScanner: BarcodeScanner,
    public navCtrl: NavController,
    public navParams: NavParams,
  ) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad ScanPage');
  }

  scan(){
    this.barcodeScanner.scan()
    .then((barcodeData)=>{
      if(barcodeData.cancelled){
        this.setValues("", "(cancelled)");
      }
      else{
        this.setValues(
          barcodeData.text || '???',
          barcodeData.format || '???'
        );
      }
    })
    .catch((err)=>{
      this.setValues(`Error ${err}`, "");
    });

  }

  clear(){
    this.setValues("", "");
  }

  setValues(s, f){
    this.scannedText = s;
    this.format = f;
  }

}
