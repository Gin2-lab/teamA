import { Component } from '@angular/core';
import { IonicPage, NavController } from 'ionic-angular';
//位置情報取得
import { Geolocation, GeolocationOptions } from '@ionic-native/geolocation';
import { HTTP } from '@ionic-native/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';

/**
 * Generated class for the GeolocationPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-geolocation',
  templateUrl: 'geolocation.html',
})
export class GeolocationPage {

  ionViewDidLoad() {
    console.log('ionViewDidLoad GeolocationPage');
  }

  // Flags
  isLocAvail: boolean;
  isLocError: boolean;

  // options
  enableHighAccuracy: boolean = false;

  // Results
  loc_lng: number;
  loc_lat: number;
  rev_geo: string;

  constructor(
    private geolocation: Geolocation,
    private http: HTTP,
    public navCtrl: NavController) { }

  initFlags() {
    this.isLocAvail = false;
    this.isLocError = false;
  }

  ngOnInit() {
    this.initFlags();
  }

  onHighAccuracyChange(t: boolean) {
    this.enableHighAccuracy = t;
  }

  getLocation() {
    console.log('getLocation call');
    this.initFlags();

    // オプションの設定
    let options: GeolocationOptions = {
      enableHighAccuracy: this.enableHighAccuracy
    };

    // 緯度経度の取得
    this.geolocation.getCurrentPosition(options)
      .then((resp) => {
        this.loc_lng = resp.coords.longitude;
        this.loc_lat = resp.coords.latitude;

        this.isLocAvail = true;
        this.isLocError = false;

        console.log('getCurrentPosition call');
        
        // 住所の取得
        if (this.isLocAvail) {

          let apiKey = "YOUR KEY GOES HERE";

          console.log('https://maps.googleapis.com/maps/api/geocode/json?latlng='+ `${this.loc_lat},${this.loc_lng}&key=${apiKey}`);
/*
          this.http.get(
            'https://maps.googleapis.com/maps/api/geocode/json?latlng='
            + `${this.loc_lat},${this.loc_lng}&key=${apiKey}`, {}, {})
            .then((httpResp) => {
              this.rev_geo = JSON.parse(httpResp.data).results[0].formatted_address;
            })
            .catch((err) => {
              console.log(err);
            });
*/
        }
      })
      .catch((err) => {
        this.isLocAvail = false;
        this.isLocError = true;
        console.log(err);
      });
  }

}