import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GeolocationPage } from './geolocation';

@NgModule({
  declarations: [
    GeolocationPage,
  ],
  imports: [
    IonicPageModule.forChild(GeolocationPage),
  ],
  //外部から参照可能にする
  exports: [
    GeolocationPage
  ]
})
export class GeolocationPageModule {}
