import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NishimuraPage } from './nishimura';

@NgModule({
  declarations: [
    NishimuraPage,
  ],
  imports: [
    IonicPageModule.forChild(NishimuraPage),
  ],
})
export class NishimuraPageModule {}
