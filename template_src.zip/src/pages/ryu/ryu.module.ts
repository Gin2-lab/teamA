import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RyuPage } from './ryu';

@NgModule({
  declarations: [
    RyuPage,
  ],
  imports: [
    IonicPageModule.forChild(RyuPage),
  ],
})
export class RyuPageModule {}
