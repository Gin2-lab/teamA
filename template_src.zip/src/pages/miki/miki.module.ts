import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MikiPage } from './miki';

@NgModule({
  declarations: [
    MikiPage,
  ],
  imports: [
    IonicPageModule.forChild(MikiPage),
  ],
})
export class MikiPageModule {}
