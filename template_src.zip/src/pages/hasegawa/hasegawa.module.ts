import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HasegawaPage } from './hasegawa';

@NgModule({
  declarations: [
    HasegawaPage,
  ],
  imports: [
    IonicPageModule.forChild(HasegawaPage),
  ],
})
export class HasegawaPageModule {}
